$(document).ready(function(){
    
    showProducts();
    showCategories();
    showSizes();

    $(".sort-element").click(onSortProducts);
});

/* SORTIRANJE */

function onSortProducts(e){
    e.preventDefault(); // zato sto je link -> da se HREF ne izvrsi

    // imena DATA atributa NE mogu biti camilcase! npr: sortBy

    let sortBy = $(this).data('sortby'); // naziv svojstva po kome se sortira
    let order = $(this).data('order');
    console.log(sortBy + "=" + order);
    rememberSort(sortBy, order);

    ajaxProducts(function(products){
        sortProducts(products, sortBy, order);
        printProducts(products);
    });
}

/* PRIKAZ - PROIZVODI */

function ajaxProducts(callbackSuccess){ // Svuda bi se morao pisati ovakav zahtev -> za sort, za filter - ova funkcija nam omogucava da na 1 mestu definisemo izgled AJAX zahteva, a ono sto ce se desiti OnSuccess -> saljemo kao callback funkciju.
    $.ajax({
        url: "data/products.json",
        method: "GET",
        success: callbackSuccess
    });
}
function showProducts() {
    // $.ajax({
    //     url: "data/products.json",
    //     method: "GET",
    //     success: function(products){
    //         sortFilterByRemembered(products);
    //         printProducts(products);
    //     }
    // });

    ajaxProducts(
        function(products){
            // iz localStorage -> ako je postojala selekcija ranije, da se po tome sortira pri ucitavanju strane
            sortFilterByRemembered(products);
            printProducts(products);

            // Ovde moramo pozvati za prikaz boja, jer prikaz boja zavisi od JSON-a "produsts", odatle se iscitavaju boje
            showColors(products);
        }
    );
}

function printProducts(products){
    let html = "";
    if(products.length > 0){
        for(let product of products){
            html += printSingleProduct(product);
        }
    } else {
        html += "<h3 class='block-4 text-center'>No products.</h3>";
    }
    
    $("#products").html(html);
}


/* LOCAL STORAGE - pamcenje sta je korisnik izabrao za filter i sort */

function sortFilterByRemembered(products){
    if(!isEmptyStorage()){
        let selection = getStorage();
        if(!isEmptyStorage()){
            sortProducts(products, selection.sortBy, selection.order);
        }
    }
}

function sortProducts(products, sortBy, order) {
    products.sort(function(a,b){
        let valueA = (sortBy=='price')? a.price.new : a.name;
        let valueB = (sortBy=='price')? b.price.new : b.name;
        if(valueA > valueB)
            return order=='asc' ? 1 : -1;
        else if(valueA < valueB)
            return order=='asc' ? -1 : 1;
        else 
            return 0;
    });
}

function rememberSort(sortBy, order){
    setStorage({ sortBy: sortBy, order: order});
}

/* PRIKAZ - KATEGORIJE */

function showCategories(){
    $.ajax({
        url: "data/categories.json",
        method: "GET",
        success: function(categories){
            printCategories(categories);
        }
    })
}

function printCategories(categories){
    let html = "";
    for(let category of categories){
        html += printSingleCategory(category);
    }
    $("#categories").html(html);

    // Tek ovog trenutka na stranici postoje linkovi sa kategrijama, tako da se dogadjaj dodaje ovde
    $('.filter-category').click(onFilterByCategory);
}

/* FILTRIRANJE - PO KATEGORIJI */

function onFilterByCategory(e){
    e.preventDefault();

    let categoryId = $(this).data('id');

    ajaxProducts(function(products){
        products = filterByCategory(products, categoryId);
        printProducts(products);
    });
}

function filterByCategory(products, categoryId){
    return products.filter(x => x.category.id == categoryId);
}

/* PRIKAZ - VELICINE */

function showSizes(){
    $.ajax({
        url: "data/sizes.json",
        method: "GET",
        success: function(sizes){
            printSizes(sizes);
        }
    })
}

function printSizes(sizes){
    let html = "";
    for(let size of sizes){
        html += printSingleSize(size);
    }
    $("#sizes").html(html);

    $('.size-element').click(onFilterBySizes);
}

/* FILTRIRANJE - PO VELICINI */

function onFilterBySizes(){
    let checkedChbs = $('.size-element:checked') // Ne radimo $(this), jer nam trebaju SVI ceckirani, a ne samo onaj checkbox koji je upravo cekiran.
    console.log(checkedChbs);
    let checkedSizes = [];
    for(let x of checkedChbs){
        checkedSizes.push(parseInt(x.value));
    }
    // Kraci nacin: $('.size-element:checked').map( function() { this.value });
    ajaxProducts(function(products){
        if(checkedSizes.length>0){
            products = filterBySizes(products, checkedSizes);
        }
        printProducts(products);
    })
}

function filterBySizes(products, checkedSizes){
    return products.filter( product => {
        let sizes = product.sizes.map(x => x.id); // funkcija map() od postojeceg niza ID i TITLE ce napraviti niz samo sa ID vrednostima - niz objekata mapira u niz ID u ovom slucaju
        let showProduct = true;
        for(let size of checkedSizes){
            if(!inArray(sizes, size)){
                showProduct = false;
                return;
            }
        }
        return showProduct; // ako je TRUE - filter() funkcija uzima taj element iz niza "products", ako je false - preskace ga
    })
}

/* PRIKAZ - BOJE */
function showColors(products){
    let differentColors = [];
    for(let product of products){
        for(let color of product.colors){
            if(isUniqueColor(differentColors, color)){
                differentColors.push(color);
            }
        }
    }

    printColors(differentColors, products); // Proizvodi nam trebaju zbog broja pored boje
}

function isUniqueColor(differentColors, color){
    let isUnique = false;
    if(differentColors.length > 0){
        let differentColorsIds = differentColors.map(x => x.id);
        console.log(differentColors);
        if(!inArray(differentColorsIds, color.id)){
            isUnique = true;
        }
    } else {
        isUnique = true;
    }
    return isUnique;
}

function printColors(colors, products){
    let html = "";
    for(let color of colors){
        html+= printSingleColor(color, products);
    }
    $("#colors").html(html);

    $(".color-element").click(onFilterByColor);
}

/* FILTRIRANJE - PO BOJI */

function onFilterByColor(e){
    e.preventDefault();

    let colorId = $(this).data("id");

    ajaxProducts(function(products){
        products = filterByColor(products, colorId);
        printProducts(products);
    })
}

function filterByColor(products, colorId){
    return products.filter(x=> {
        let ids = x.colors.map(x=>x.id)
        return inArray(ids, colorId);
    })
}

/* HELPER FUNKCIJE */

function getStorage(){
    return JSON.parse(localStorage.getItem('sort'));
}
function setStorage(value){
    return localStorage.setItem('sort', JSON.stringify(value));
}
function isEmptyStorage(){
    return localStorage.getItem('sort') === null;
}

function inArray(array, element){
    return array.indexOf(element)!==-1;
}

/* STAMPANJE NA STRANICI */

function printSingleProduct(product){
    return `
    <div class="col-sm-6 col-lg-4 mb-4" data-aos="fade-up">
      <div class="block-4 text-center border">
        <figure class="block-4-image">
          <a href="shop-single.html"><img src="images/${ product.picture.src }" alt="${ product.picture.alt }" class="img-fluid"></a>
        </figure>
        <div class="block-4-text p-4">
          
          <h3><a href="shop-single.html">${ product.name }</a></h3>
          <p class="stars">
              ${ printStars(product.stars) }
          </p>
          <p class="mb-0">${ product.description }</p>
          
          <p class="delivery"><i class="fa fa-car"></i> ${ printDelivery(product.delivery) }</p>
          <p><span class="text-primary font-weight-bold">$${ product.price.new }</span> <del>$${ product.price.old }</del></p>
        </div>
      </div>
    </div>`;
}

function printSingleCategory(category, numOfProducts){
    return `<li class="mb-1"><a href="#" class="d-flex filter-category" data-id="${ category.id }"><span>${ category.title }</span> <span class="text-black ml-auto">(${ category.numOfProducts })</span></a></li>`;
}

function printSingleSize(size){
    return `<label for="s_sm" class="d-flex">
        <input type="checkbox" class="mr-2 mt-1 size-element" value="${ size.id }"> <span class="text-black">${ size.title }</span>
    </label>`;
}

function printSingleColor(color, products){
    return `<a href="#" class="d-flex color-item align-items-center color-element" data-id="${ color.id }" >
    <span class="color d-inline-block rounded-circle mr-2" 
    style="background-color: ${ color.color }" ></span> <span class="text-black">${ color.title } (${ printNumOfProducts(products, color.id)})</span>
  </a>`;
}

function printNumOfProducts(products, colorId){
    return filterByColor(products, colorId).length;
}

function printStars(stars){
    let htmlStars = "";
    for(let i=1; i <= 5; i++){
        if(i <= stars){
            htmlStars += "<i class='fa fa-star'></i>";
        } else {
            htmlStars += "<i class='fa fa-star-o'></i>";
        }
    }
    return htmlStars;
}

function printDelivery(delivery){
    if(!delivery)
        return "<del>Delivery</del>";
    return "Delivery";
}